import React from 'react';
import axios from 'axios';

const Home = ({ setUser }) => {
    const handleGetApi = async () => {
        const response = await axios.get('https://jsonplaceholder.typicode.com/posts');
        console.log("This is the response from the API");
        console.log(response.data);
    };

    const handlePostApi = async () => { // Corrected `handlePostAPi` to `handlePostApi`
        const response = await axios.post('https://jsonplaceholder.typicode.com/posts', {
            title: 'sampletitle',
            body: 'samplebody',
            userId: 2,
        });
        console.log("This is the response from the Post API");
        console.log(response.data);
    };

    const handleLogout = () => {
        localStorage.removeItem('user');
        setUser(null);
    };

    return (
        <div>
            <h2>Home</h2>
            <button onClick={handleGetApi}>Get API sample</button>
            <button onClick={handlePostApi}>Post API sample</button>
            <button onClick={handleLogout}>Logout</button>
        </div>
    );
};

export default Home;