import React, {useState} from 'react';
import{GoogleLogin} from '@react-oauth/google';
import {useNavigate} from 'react-router-dom';

const Login = ({setUser}) => {
    const navigate = useNavigate();

    const handleGoogleLogin = (credentialResponse) => {
        const user = {username: credentialResponse.profileObj.name};
        localStorage.setItem('user', JSON.stringify(user));
        setUser(user);
        navigate('/Home');
    };

    return (
        <div>
            <h2>Login</h2>
            <GoogleLogin
                onSuccess={handleGoogleLogin}
                onFailure={(error) => console.error('Login Failed:', error)}
            />
        </div>
    );
};

export default Login;