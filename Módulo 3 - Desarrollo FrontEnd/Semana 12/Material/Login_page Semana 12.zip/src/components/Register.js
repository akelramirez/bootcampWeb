import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Register = () => {
    const navigate = useNavigate();
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [age, setAge] = useState('');

    const handleRegister = () => {
        // Store user data
        const users = JSON.parse(localStorage.getItem('users')) || [];
        users.push({ username, password, age });
        localStorage.setItem('users', JSON.stringify(users));
        alert('User registered!');
    };

    const handleLoginClick = () => {
        navigate('/login');
    };

    return (
        <div>
            <h2>Register</h2>
            <input
                type="text"
                placeholder="Username"
                onChange={(e) => setUsername(e.target.value)}
            />
            <input
                type="password"
                placeholder="Password"
                onChange={(e) => setPassword(e.target.value)}
            />
            <input
                type="number"
                placeholder="Age"
                onChange={(e) => setAge(e.target.value)}
            />
            <button onClick={handleRegister}>Register</button>
            <button onClick={handleLoginClick}>Back to Login</button> {/* Added Back to Login button */}
        </div>
    );
};

export default Register;